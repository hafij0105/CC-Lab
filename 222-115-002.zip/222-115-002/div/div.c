#include <stdio.h>

int main() {
    int a, b;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    if (b == 0) {
        printf("Error: Division by zero!\n");
        return 1;
    }
    printf("Quotient: %d\n", a / b);
    return 0;
}
